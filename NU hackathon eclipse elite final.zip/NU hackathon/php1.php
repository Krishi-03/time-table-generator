<?php

function isallow($tableboard, $row, $col, $N) { 
    for ($i = 0; $i < $col; $i++)
        if ($tableboard[$row][$i])
            return false;
    for ($i = $row, $j = $col; $i >= 0 && $j >= 0; $i--, $j--)
        if ($tableboard[$i][$j])
            return false;
    for ($i = $row, $j = $col; $j >= 0 && $i < $N; $i++, $j--)
        if ($tableboard[$i][$j])
            return false;
    return true;
}

function solvetable($tableboard, $col, $N) {
    if ($col == $N) {
        $subjects=array("PSC","PS","CA","WT","OS");
        
        for ($i = 0; $i < $N; $i++) {
            $z = 2;
            $zz = -1;
            for ($j = 0; $j < $N; $j++) {
                if($tableboard[$i][$j] == 1){
                    $zz = $j;
                } 
            }

            for($j = $zz+1; $j < $N+$zz ; $j++){
                $tableboard[$i][($j % $N)]=$z;
                $z++;
            }
        }
        for ($i = 0; $i < $N; $i++) {
            for ($j = 0; $j < $N; $j++) {
                echo $subjects[$tableboard[$i][$j]-1];
                echo "\t\t";
                
            }
            echo "<br>";
            
        }
        echo "\n";
        return true;
    }
    $found = false;
    for ($i = 0; $i < $N; $i++) {
        if (isallow($tableboard, $i, $col, $N)) {
            $tableboard[$i][$col] = 1;
            if (solvetable($tableboard, $col + 1, $N)) {
                $found = true;
                break;
            }
            $tableboard[$i][$col] = 0;
        }
    }
    return $found;
}

function table($N) {
    $tableboard = array();
    for ($i = 0; $i < $N; $i++) {
        for ($j = 0; $j < $N; $j++) {
            $tableboard[$i][$j] = 0;
        }
    }
    solvetable($tableboard, 0, $N);
}

table(5);

?>